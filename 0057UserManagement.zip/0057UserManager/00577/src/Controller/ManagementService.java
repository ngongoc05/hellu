/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import java.util.ArrayList;

import Common.UserManageFunction;
import Model.User;

public class ManagementService {
    protected ArrayList<User> userList = new ArrayList<>();
    
    private UserManageFunction userManageFunction = new UserManageFunction();

    public void handleCreateNewUserAccount() {
        userManageFunction.createNewUserAccount(userList);
    }
    public void handeLogin() {
        userManageFunction.login(userList);
    }
}
